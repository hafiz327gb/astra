const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Dhht1N5R.js","./index-HugCEhWk.js"])))=>i.map(i=>d[i]);
import{_ as e}from"./index-D2SiNtwl.js";import{registerPlugin as t}from"./index-HugCEhWk.js";const _=t("Network",{web:()=>e(()=>import("./web-Dhht1N5R.js"),__vite__mapDeps([0,1]),import.meta.url).then(r=>new r.NetworkWeb)});export{_ as Network};
